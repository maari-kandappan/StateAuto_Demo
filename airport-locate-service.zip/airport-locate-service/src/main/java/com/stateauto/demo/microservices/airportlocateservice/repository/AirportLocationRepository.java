package com.stateauto.demo.microservices.airportlocateservice.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;


public interface AirportLocationRepository extends JpaRepository<AirportLocation, Long> {
	
	List<AirportLocation> findByStateAbbr(String stateAbbr);
	

}
