package com.stateauto.demo.microservices.airportlocateservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

@SpringBootApplication
@EnableDiscoveryClient
public class AirportLocateServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(AirportLocateServiceApplication.class, args);
	}

}
