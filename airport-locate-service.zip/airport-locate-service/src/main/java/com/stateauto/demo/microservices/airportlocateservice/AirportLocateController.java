package com.stateauto.demo.microservices.airportlocateservice;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.stateauto.demo.microservices.airportlocateservice.repository.AirportLocation;
import com.stateauto.demo.microservices.airportlocateservice.repository.AirportLocationRepository;

@RestController
public class AirportLocateController {
	
	@Autowired
	private AirportLocationRepository locRepository;
	
	@GetMapping("/locate-airport/state/{state}/latitude/{latitude}/longitude/{longitude}")
	public AirportLocation locateClosestAirport(@PathVariable String state, @PathVariable BigDecimal latitude, 
			@PathVariable BigDecimal longitude) {

		List<AirportLocation> airportLocations = locRepository.findByStateAbbr(state);
		return getClosestAirpotLocation (airportLocations, latitude, longitude);
	}
	
	private AirportLocation getClosestAirpotLocation(List<AirportLocation> airportLocations, BigDecimal latitude, BigDecimal longitude) {
		
		if(airportLocations.isEmpty()) {
			return new AirportLocation();
		}
		
		AirportLocation closestLocation = null;
		BigDecimal distance = null;
		
		for(AirportLocation airportLocation : airportLocations) {
			
			String locationPoint = airportLocation.getLocationPoint();
			String[] locationPointInArray = locationPoint.split(",");
			double dist = Math.sin(Math.toRadians(latitude.doubleValue())) * Math.sin(Math.toRadians(Double.parseDouble(locationPointInArray[0]))) + 
					Math.cos(Math.toRadians(latitude.doubleValue())) * Math.cos(Math.toRadians(Double.parseDouble(locationPointInArray[0]))) * 
					Math.cos(Math.toRadians(longitude.doubleValue() - Double.parseDouble(locationPointInArray[0])));
			dist = Math.acos(dist);
			dist = Math.toDegrees(dist);
			dist = dist * 60 * 1.1515;
			if(distance == null) {
				distance = new BigDecimal(dist);
				closestLocation = airportLocation;
			} else {
				if(distance.doubleValue() < dist) {
					distance = new BigDecimal(dist);
					closestLocation = airportLocation;
				}
			}
		}
		return closestLocation;
	}

}
