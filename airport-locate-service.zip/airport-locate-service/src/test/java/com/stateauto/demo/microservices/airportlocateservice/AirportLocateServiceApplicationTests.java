package com.stateauto.demo.microservices.airportlocateservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AirportLocateServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
