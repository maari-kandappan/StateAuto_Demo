package com.stateauto.demo.microservices.spotlocationservice.proxies;

import java.math.BigDecimal;

import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.stateauto.demo.microservices.spotlocationservice.beans.AirportLocationBean;
import com.stateauto.demo.microservices.spotlocationservice.beans.BeachLocationBean;

@FeignClient(name="zuul-api-gateway")
@RibbonClient(name="airport-locate-service, beach-locate-service")
public interface SpotLocateProxy {
	
	@GetMapping("/airport-locate-service/locate-airport/state/{state}/latitude/{latitude}/longitude/{longitude}")
	public AirportLocationBean locateClosestAirport(@PathVariable("state") String state, @PathVariable("latitude") BigDecimal latitude, 
			@PathVariable("longitude") BigDecimal longitude);

	
	@GetMapping("/beach-locate-service/locate-beach/state/{state}/latitude/{latitude}/longitude/{longitude}")
	public BeachLocationBean locateClosestBeach(@PathVariable("state") String state, @PathVariable("latitude") BigDecimal latitude, 
			@PathVariable("longitude") BigDecimal longitude);

}
