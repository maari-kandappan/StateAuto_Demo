package com.stateauto.demo.microservices.spotlocationservice;

import java.math.BigDecimal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.stateauto.demo.microservices.spotlocationservice.beans.AirportLocationBean;
import com.stateauto.demo.microservices.spotlocationservice.beans.BeachLocationBean;
import com.stateauto.demo.microservices.spotlocationservice.proxies.SpotLocateProxy;

@RestController
public class SpotLocationController {

	@Autowired
	private SpotLocateProxy spotProxy;

	@GetMapping("/locate-spot/airport/state/{state}/latitude/{latitude}/longitude/{longitude}")
	public AirportLocationBean retrieveClosestAirportSpot(@PathVariable String state, @PathVariable BigDecimal latitude,
			@PathVariable BigDecimal longitude) {

		return spotProxy.locateClosestAirport(state, latitude, longitude);
	}

	@GetMapping("/locate-spot/beach/state/{state}/latitude/{latitude}/longitude/{longitude}")
	public BeachLocationBean retrieveClosestBeachSpot(@PathVariable String state, @PathVariable BigDecimal latitude, 
			@PathVariable BigDecimal longitude) {
		  
		return spotProxy.locateClosestBeach(state, latitude, longitude); 
	}
	  
	 
}
