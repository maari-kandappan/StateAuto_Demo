package com.stateauto.demo.microservices.spotlocationservice.beans;

public class AirportLocationBean {
	
	private Long id;
	
	private String stateAbbr;
	
	private String airportName;
	
	private String locationPoint;

	public AirportLocationBean () {
		
	}
	public AirportLocationBean(Long id, String stateAbbr, String airportName, String locationPoint) {
		super();
		this.id = id;
		this.stateAbbr = stateAbbr;
		this.airportName = airportName;
		this.locationPoint = locationPoint;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getStateAbbr() {
		return stateAbbr;
	}

	public void setStateAbbr(String stateAbbr) {
		this.stateAbbr = stateAbbr;
	}

	public String getAirportName() {
		return airportName;
	}

	public void setAirportName(String airportName) {
		this.airportName = airportName;
	}

	public String getLocationPoint() {
		return locationPoint;
	}

	public void setLocationPoint(String locationPoint) {
		this.locationPoint = locationPoint;
	}

}
