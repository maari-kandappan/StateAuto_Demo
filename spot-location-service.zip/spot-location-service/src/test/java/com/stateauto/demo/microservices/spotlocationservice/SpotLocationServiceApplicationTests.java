package com.stateauto.demo.microservices.spotlocationservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpotLocationServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
