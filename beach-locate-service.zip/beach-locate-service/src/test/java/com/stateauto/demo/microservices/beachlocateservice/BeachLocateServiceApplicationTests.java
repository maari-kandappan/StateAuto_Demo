package com.stateauto.demo.microservices.beachlocateservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BeachLocateServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
