insert into beach_location (id, state_abbr, beach_name, location_point) values (1000, 'FL', 'Fernandina Beach', '30.6551289,-81.491119');
insert into beach_location (id, state_abbr, beach_name, location_point) values (1001, 'FL', 'Daytona Bean', '29.2102483,-81.1666499');
insert into beach_location (id, state_abbr, beach_name, location_point) values (1002, 'FL', 'Cocoa Beach', '28.3286305,-80.6596439');
insert into beach_location (id, state_abbr, beach_name, location_point) values (1003, 'FL', 'West Palm Beach', '26.7419207,-80.1990799');
insert into beach_location (id, state_abbr, beach_name, location_point) values (1004, 'FL', 'Delray Beach', '26.4560036,-80.1271934');
insert into beach_location (id, state_abbr, beach_name, location_point) values (1005, 'FL', 'Miami Beach', '25.8102373,-80.175161');
insert into beach_location (id, state_abbr, beach_name, location_point) values (1006, 'FL', 'Clearwater Beach', '27.9925961,-82.7824179');
insert into beach_location (id, state_abbr, beach_name, location_point) values (1007, 'FL', 'Panama City Beach', '30.2309049,-85.9421289');
insert into beach_location (id, state_abbr, beach_name, location_point) values (1008, 'FL', 'Pensacola Beach', '30.3541359,-87.1915124');