package com.stateauto.demo.microservices.beachlocateservice.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;


public interface BeachLocationRepository extends JpaRepository<BeachLocation, Long> {
	
	List<BeachLocation> findByStateAbbr(String stateAbbr);
}
	
