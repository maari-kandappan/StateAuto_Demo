package com.stateauto.demo.microservices.beachlocateservice.repository;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class BeachLocation {
	@Id
	private Long id;
	
	@Column (name = "state_abbr")
	private String stateAbbr;
	
	@Column (name = "beach_name")
	private String beachName;
	
	@Column (name = "location_point")
	private String locationPoint;

	public BeachLocation() {
		
	}
	
	public BeachLocation(Long id, String stateAbbr, String beachName, String locationPoint) {
		super();
		this.id = id;
		this.stateAbbr = stateAbbr;
		this.beachName = beachName;
		this.locationPoint = locationPoint;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getStateAbbr() {
		return stateAbbr;
	}

	public void setStateAbbr(String stateAbbr) {
		this.stateAbbr = stateAbbr;
	}

	public String getBeachName() {
		return beachName;
	}

	public void setBeachName(String beachName) {
		this.beachName = beachName;
	}

	public String getLocationPoint() {
		return locationPoint;
	}

	public void setLocationPoint(String locationPoint) {
		this.locationPoint = locationPoint;
	}
	
	

}
